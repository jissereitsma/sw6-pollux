<?php declare(strict_types=1);

namespace Swag\Example;

use Shopware\Core\Framework\Plugin;

class SwagExample extends Plugin
{
}
