import Plugin from 'src/plugin-system/plugin.class';

export default class ExamplePlugin extends Plugin {
    init() {
        console.log('Element', this.el);
        console.log(window.PluginManager.getPluginInstancesFromElement(this.el));
    }
}
