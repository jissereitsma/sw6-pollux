console.log('main4');

//import ExamplePlugin from './example.plugin';

//window.PluginManager.register('ExamplePlugin', ExamplePlugin, '[data-example]', {})
