<?php declare(strict_types=1);

namespace Swag\Example\Struct;

use Shopware\Core\Framework\Struct\Struct;

class Foobar extends Struct
{
    public function __toString(): string
    {
        return 'foobar';
    }
}
