<?php declare(strict_types=1);

namespace Swag\Example\Storefront\Pagelet;

use Shopware\Storefront\Pagelet\Pagelet;

class ExamplePagelet extends Pagelet
{
    /**
     * @var mixed
     */
    protected $exampleData;

    /**
     * @return mixed
     */
    public function getExampleData()
    {
        return $this->exampleData;
    }

    /**
     * @param $exampleData
     */
    public function setExampleData($exampleData): void
    {
        $this->exampleData = $exampleData;
    }
}
