<?php declare(strict_types=1);

namespace Swag\Example\Event\Subscriber;

use Shopware\Storefront\Pagelet\Footer\FooterPageletLoadedEvent;
use Swag\Example\Struct\Foobar;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class AddDataToFooter implements EventSubscriberInterface
{
    public static function getSubscribedEvents(): array
    {
        return [
            FooterPageletLoadedEvent::class => 'addFoobar'
        ];
    }

    public function addFoobar(FooterPageletLoadedEvent $event): void
    {
        $foobar = new Foobar();
        $event->getPagelet()->addExtension('foobar', $foobar);
    }
}
