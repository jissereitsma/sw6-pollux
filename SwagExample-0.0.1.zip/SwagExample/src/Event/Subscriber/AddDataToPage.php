<?php declare(strict_types=1);

namespace Swag\Example\Event\Subscriber;

use Shopware\Storefront\Page\GenericPageLoadedEvent;
use Swag\Example\Struct\Foobar;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class AddDataToPage implements EventSubscriberInterface
{
    public static function getSubscribedEvents(): array
    {
        return [
            GenericPageLoadedEvent::class => 'addFoobar'
        ];
    }

    public function addFoobar(GenericPageLoadedEvent $event): void
    {
        $event->getPage()->addExtension('foobar', new Foobar());
    }
}
